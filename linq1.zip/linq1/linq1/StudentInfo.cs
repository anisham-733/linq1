﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq1
{
    internal class StudentInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string city { get; set; }
        public string Gender { get; set; }
        public StudentInfo(int i, string n, int a, string c, string g)
        {
            Id = i;
            Name = n;
            Age = a;
            city = c;
            Gender = g;
        }
    }
}
