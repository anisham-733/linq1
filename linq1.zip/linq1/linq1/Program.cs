﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linq1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<StudentInfo> Students = new List<StudentInfo>();
            Students.Add(new StudentInfo(101, "Abc", 24, "Chd", "Male"));
            Students.Add(new StudentInfo(102, "Savi", 54, "Delhi", "Female"));
            Students.Add(new StudentInfo(103, "Manvi", 14, "Asr", "Female"));
            Students.Add(new StudentInfo(104, "Suresh", 26, "Chd", "Male"));
            Students.Add(new StudentInfo(105, "Rohit", 22, "Jaipur", "Male"));
            Students.Add(new StudentInfo(106, "Karan", 21, "Asr", "Male"));
            Students.Add(new StudentInfo(107, "Nikita", 27, "Delhi", "Female"));
            var stu1 = new StudentInfo(108, "dgf", 34, "Asr", "Male");
            //Students.Add(stu1);

            var query1 = from student in Students
                         where student.Age > 26 && student.Gender == "Female"
                          orderby student.Name ascending
                          select student;
            //select * from Students where Age>26 order by Name; 
            //1. from
            //2. where
              //  4. order
              //3.. select


            var queryNew = Students.Where(x => x.Age > 26 && x.Gender == "Female").OrderBy(x => x.Name).Select(x=> new {x.Name,x.Age}).ToList();
            foreach(var student in queryNew)
            {
                Console.WriteLine(student);//as object
            }


            var query3 = (from stud in Students
                         where stud.Age > 20
                         select stud).Contains(stu1);
            //contains- where the data source contains the specified element or not-boolean result
            
            //.StartsWith
            //.Contains
            //.EndsWith
           // Console.WriteLine(query3);

            var q4 = from st in Students
                     where st.Name.StartsWith("M")
                     select st;

           
            
            foreach(StudentInfo student in query1)
            {
               // Console.WriteLine(student.Name + " " +student.Age);
            }

            var query2 = from stu in Students
                         group stu by stu.city;
            //result takes the form of lists of lists
            //Each element in the list is an object that has a Key member and a list of elements
            //that are grouped under that key.
            //When you iterate over a query that produces a sequence of groups,
            //you must use a nested foreach loop.
            //The outer loop iterates over each group, and the inner loop iterates
            //over each group's members.
            foreach(var s1 in query2)
            {
                //Console.WriteLine("\n" + s1.Key);
                foreach(var values in s1)
                {
                    //Console.WriteLine(values.Name);
                }
            }
            //Query1's result to another list
            List<StudentInfo> newList = query1.ToList();
            //Console.WriteLine($"\n New list's count : {newList.Count}");
            
            foreach(StudentInfo student in newList)
            {
                //Console.WriteLine(student.Name);
            }
        }
    }
    //JOINS
    //connectivity-using entity framework
}
